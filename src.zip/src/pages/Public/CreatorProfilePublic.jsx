import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import CreatorHero from "../../components/public/CreatorHero";
import CreatorAbout from "../../components/public/CreatorAbout";
import CreatorStats from "../../components/public/CreatorStats";
import SubscribeCard from "../../components/public/SubscribeCard";
import CreatorGallery from "../../components/public/CreatorGallery";

import "../../assets/css/PublicProfile.css";

function CreatorProfilePublic() {
  const { username } = useParams();

  const [creator, setCreator] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCreator();
  }, [username]);

  const loadCreator = async () => {
    try {
      console.log("Username from URL:", username);

      const response = await fetch(
        "https://myfanshub.club/api/get-profile.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            username,
          }),
        }
      );

      console.log("HTTP Status:", response.status);

      if (!response.ok) {
        throw new Error(`HTTP Error ${response.status}`);
      }

      const result = await response.json();

      console.log("API Response:", result);

      if (result.success) {
        console.log("Creator Loaded:", result.user);
        setCreator(result.user);
      } else {
        console.error("API returned success = false");
        console.log(result);
      }
    } catch (error) {
      console.error("Fetch Error:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <h2 style={{ textAlign: "center" }}>Loading...</h2>;
  }

  if (!creator) {
    return <h2 style={{ textAlign: "center" }}>Creator not found</h2>;
  }

  return (
    <div className="public-profile">
      <CreatorHero creator={creator} />

      <div className="public-container">
        <div className="public-left">
          <CreatorAbout creator={creator} />
          <CreatorStats creator={creator} />
          <CreatorGallery creator={creator} />
        </div>

        <div className="public-right">
          <SubscribeCard creator={creator} />
        </div>
      </div>
    </div>
  );
}

export default CreatorProfilePublic;